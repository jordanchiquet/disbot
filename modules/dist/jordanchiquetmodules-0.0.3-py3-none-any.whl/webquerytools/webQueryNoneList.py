noneList = [
    "no results found for 'summer tops for women'",
    "pretty sure you just made that up",
    "[QUERY FORWARDED TO FBI]",
    "In an effort to make a more tolerant Web 3.0 this search was refused."
]