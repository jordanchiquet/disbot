import sys

from pyfiglet import figlet_format #pyfiglet

def figgletizer(input):
    return(figlet_format(input))