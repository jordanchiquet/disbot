import pokebase as pb

print(pb.pokemon('charmander').height)

def pokedex(query):
    # try:
    #     pokeobject = pb.pokemon(query)