any = [
    "Albasha",
    "Bay Leaf",
    "Burgersmith",
    "City Pork",
    "Curbside",
    "Curry N Kabob",
    "Duang Tuan",
    "Dang's"
    "El Rancho",
    "Elsie's",
    "Fat Cow",
    "La Caretta",
    "Lit",
    "Mooyah",
    "Pluckers",
    "Serops",
    "Superior Grill",
    "Sushi Masa",
    "Tsunami",
    "Umami",
    "Velvet Cactus"
]

fast = [
    "mikky d",
    "the King calls you to arms...",
    "im thinkin arbys",
    "time to shit mas",
    "Don't ask who Jack is...",
    "Wendy's VEVO",
    "Treat yourself at the Chic"
]

dinner = [
    
]