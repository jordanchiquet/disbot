import os

host = os.environ.get('AWSPUBIP')
user = os.environ.get('SQLUSER')
passwd = os.environ.get('SQLPW')
